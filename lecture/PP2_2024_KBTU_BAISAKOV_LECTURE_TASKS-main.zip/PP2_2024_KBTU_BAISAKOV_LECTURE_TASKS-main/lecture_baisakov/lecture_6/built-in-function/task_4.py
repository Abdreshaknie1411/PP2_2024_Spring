from time import sleep

num, miliseconds = int(input()), int(input())
sleep(miliseconds / 1000)

print(f'Square root of {num} after 2123 miliseconds is {miliseconds}')

