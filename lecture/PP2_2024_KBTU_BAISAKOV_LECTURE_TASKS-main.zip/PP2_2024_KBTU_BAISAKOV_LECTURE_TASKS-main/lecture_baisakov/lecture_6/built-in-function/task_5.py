from random import randint 
print(all((randint(0, 1) for _ in range(5))))