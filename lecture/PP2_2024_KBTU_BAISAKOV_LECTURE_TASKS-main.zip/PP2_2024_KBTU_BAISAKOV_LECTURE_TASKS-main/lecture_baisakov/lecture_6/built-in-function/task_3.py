string = 'aza'
check = ''.join(reversed(string))
print(string == check)
