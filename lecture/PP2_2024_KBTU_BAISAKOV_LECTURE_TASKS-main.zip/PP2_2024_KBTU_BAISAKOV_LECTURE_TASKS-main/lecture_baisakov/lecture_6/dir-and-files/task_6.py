import string

for i in string.ascii_uppercase:
    open(f'{i}.txt', 'w')
    