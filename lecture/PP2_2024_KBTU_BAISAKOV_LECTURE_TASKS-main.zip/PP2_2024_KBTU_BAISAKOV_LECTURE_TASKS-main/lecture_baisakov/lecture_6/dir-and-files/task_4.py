with open('test.txt') as text:
    print(len(list(text)))


    