x = "John"
# is the same as
x = 'John'