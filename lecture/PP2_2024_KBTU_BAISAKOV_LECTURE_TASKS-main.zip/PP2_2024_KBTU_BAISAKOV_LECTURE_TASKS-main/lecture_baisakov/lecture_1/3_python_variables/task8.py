x = 5
y = 10
z = x + y
print(z)
