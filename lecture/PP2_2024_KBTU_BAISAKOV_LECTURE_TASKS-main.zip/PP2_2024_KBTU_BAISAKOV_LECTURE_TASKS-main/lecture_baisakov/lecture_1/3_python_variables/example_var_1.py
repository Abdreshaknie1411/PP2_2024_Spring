x = 5
y = "John"
print(x)
print(y)