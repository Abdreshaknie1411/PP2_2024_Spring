x = 5
y = "John"
print(type(x))
print(type(y))