x = 5
y = "Hello, World!"