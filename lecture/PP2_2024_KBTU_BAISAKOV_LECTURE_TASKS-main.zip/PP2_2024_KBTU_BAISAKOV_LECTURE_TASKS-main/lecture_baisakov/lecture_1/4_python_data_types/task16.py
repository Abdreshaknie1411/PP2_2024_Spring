x = ("apple", "banana", "cherry")
print(type(x))  # tuple
