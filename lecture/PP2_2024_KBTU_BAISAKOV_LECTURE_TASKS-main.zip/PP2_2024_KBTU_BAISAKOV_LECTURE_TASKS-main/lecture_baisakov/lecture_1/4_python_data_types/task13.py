x = "Hello World"
print(type(x))  # str