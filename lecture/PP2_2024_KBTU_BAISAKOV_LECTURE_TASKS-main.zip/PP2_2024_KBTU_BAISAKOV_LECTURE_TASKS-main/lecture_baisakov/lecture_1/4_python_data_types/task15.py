x = ["apple", "banana", "cherry"]
print(type(x))  # list
