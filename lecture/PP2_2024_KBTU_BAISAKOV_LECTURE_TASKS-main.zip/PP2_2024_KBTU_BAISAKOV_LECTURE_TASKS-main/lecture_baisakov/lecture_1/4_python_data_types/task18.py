x = True
print(type(x))  # bool
