x = 20.5
print(type(x))  # float