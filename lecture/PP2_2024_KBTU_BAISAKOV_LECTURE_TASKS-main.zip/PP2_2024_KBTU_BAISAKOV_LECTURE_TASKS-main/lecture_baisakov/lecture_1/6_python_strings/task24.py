txt = "Hello World"
x = txt[2:5]
