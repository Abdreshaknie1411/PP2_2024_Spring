a = " Hello, World! "
print(a.strip()) # returns "Hello, World!"