txt = "Hello World"
txt = txt.upper()
