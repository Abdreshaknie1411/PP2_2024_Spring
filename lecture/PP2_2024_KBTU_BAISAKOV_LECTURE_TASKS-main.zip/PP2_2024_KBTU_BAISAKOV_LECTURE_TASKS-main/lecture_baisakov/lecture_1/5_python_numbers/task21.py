x = 5
x = complex(x)