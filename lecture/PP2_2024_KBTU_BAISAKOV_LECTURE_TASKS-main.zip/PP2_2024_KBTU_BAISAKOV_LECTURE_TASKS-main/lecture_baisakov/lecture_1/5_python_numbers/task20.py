x = 5.5
x = int(x)