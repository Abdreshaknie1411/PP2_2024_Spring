x = 1
y = 35656222554887711
z = -3255522

print(type(x))
print(type(y))
print(type(z))