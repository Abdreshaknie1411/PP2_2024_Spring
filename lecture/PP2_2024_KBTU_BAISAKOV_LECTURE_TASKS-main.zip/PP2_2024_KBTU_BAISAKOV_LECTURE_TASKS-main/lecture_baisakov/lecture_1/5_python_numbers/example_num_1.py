x = 1    # int
y = 2.8  # float
z = 1j   # complex