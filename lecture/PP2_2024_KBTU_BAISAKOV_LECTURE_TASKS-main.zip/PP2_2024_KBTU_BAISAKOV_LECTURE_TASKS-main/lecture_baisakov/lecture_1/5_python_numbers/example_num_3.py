x = 1.10
y = 1.0
z = -35.59

print(type(x))
print(type(y))
print(type(z))