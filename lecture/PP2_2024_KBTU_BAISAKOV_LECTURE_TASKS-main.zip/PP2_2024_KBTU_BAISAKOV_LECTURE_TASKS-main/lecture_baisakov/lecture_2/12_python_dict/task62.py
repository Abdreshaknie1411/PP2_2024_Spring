car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}
car.clear()
