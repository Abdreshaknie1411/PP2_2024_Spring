thisdict = {
    'name' : 'Tamirlan',
    'age': 18,
    'Uni' : 'KBTU',
    'like_python': True,
}

x = thisdict.get('name')