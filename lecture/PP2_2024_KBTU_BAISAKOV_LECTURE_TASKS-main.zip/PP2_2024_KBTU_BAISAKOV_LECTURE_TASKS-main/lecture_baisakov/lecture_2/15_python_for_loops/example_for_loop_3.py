for x in range(6):
  if x == 3: break
  print(x)
else:
  print("Finally finished!")