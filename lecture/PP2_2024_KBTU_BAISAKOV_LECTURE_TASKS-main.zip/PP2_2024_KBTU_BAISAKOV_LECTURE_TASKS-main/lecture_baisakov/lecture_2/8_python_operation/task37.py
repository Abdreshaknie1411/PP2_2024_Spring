if 5 != 10:
  print("5 and 10 is not equal")