if 5 == 10 or 4 == 4:
  print("At least one of the statements is true")