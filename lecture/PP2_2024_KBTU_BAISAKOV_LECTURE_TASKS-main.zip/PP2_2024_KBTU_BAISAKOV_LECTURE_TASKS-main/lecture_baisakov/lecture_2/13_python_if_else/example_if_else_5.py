a = 200
b = 33
c = 500
if a > b and c > a:
  print("Both conditions are True")