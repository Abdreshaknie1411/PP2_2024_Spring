a = b = c = d = 0
if a == b or c == d:
    print("Hello")