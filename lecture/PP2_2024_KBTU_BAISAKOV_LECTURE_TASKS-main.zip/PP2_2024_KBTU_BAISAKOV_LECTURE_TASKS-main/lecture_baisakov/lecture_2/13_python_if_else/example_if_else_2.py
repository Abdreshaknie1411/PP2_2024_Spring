from example_if_else_1 import a, b

if a > b: print("a is greater than b")