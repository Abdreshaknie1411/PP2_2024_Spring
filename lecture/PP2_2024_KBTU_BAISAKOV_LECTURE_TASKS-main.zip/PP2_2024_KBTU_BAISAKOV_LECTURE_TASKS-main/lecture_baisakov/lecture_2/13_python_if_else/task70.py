a = 2
b = 5
print("YES") if a == b else print("NO")