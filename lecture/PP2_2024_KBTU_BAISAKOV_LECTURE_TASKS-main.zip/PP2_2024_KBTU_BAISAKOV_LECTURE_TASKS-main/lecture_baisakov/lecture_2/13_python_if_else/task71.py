a = 2
b = 50
c = 2
if a == c or b == c:
    print("YES")