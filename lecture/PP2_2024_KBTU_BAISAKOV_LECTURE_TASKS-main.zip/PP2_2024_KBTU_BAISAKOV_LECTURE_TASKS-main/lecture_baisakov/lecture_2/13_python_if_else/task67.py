a = b = c = d = 0
if a == b and c == d:
    print("Hello")