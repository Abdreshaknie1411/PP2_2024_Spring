a = 330
b = 330
print("A") if a > b else print("=") if a == b else print("B")