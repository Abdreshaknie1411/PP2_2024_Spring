fruits = ["apple", "banana", "cherry"]
fruits[0] = "kiwi"
