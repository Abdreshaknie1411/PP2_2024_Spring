thislist = ["apple", "banana", "cherry"]
thislist.insert(2, "watermelon")
print(thislist)