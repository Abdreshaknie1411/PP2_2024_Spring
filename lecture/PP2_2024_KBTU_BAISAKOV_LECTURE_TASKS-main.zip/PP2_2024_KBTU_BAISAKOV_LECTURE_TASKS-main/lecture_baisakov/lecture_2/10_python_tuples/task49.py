fruits = ("apple", "banana", "cherry")
print(len(fruits))