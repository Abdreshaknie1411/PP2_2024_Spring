thisset = {"apple", "banana", "cherry"}

thisset.discard("banana")

print(thisset)

# also we can use remove, but if we use remove we can take error if we took them None object

thisset = {"apple", "banana", "cherry"}

thisset.remove("banana")

print(thisset)