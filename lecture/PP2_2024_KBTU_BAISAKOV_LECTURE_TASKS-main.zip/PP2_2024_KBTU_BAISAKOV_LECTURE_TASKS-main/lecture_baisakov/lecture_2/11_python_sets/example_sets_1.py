thisset = {"apple", "banana", "cherry"}

thisset.add("orange")

print(thisset)