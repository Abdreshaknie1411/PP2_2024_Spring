fruits = {"apple", "banana", "cherry"}
fruits.discard("banana")
