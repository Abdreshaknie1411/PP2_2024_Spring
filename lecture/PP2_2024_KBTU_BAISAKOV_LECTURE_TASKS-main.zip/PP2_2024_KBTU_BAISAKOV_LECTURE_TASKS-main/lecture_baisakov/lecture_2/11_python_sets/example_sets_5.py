thisset = {"apple", "banana", "cherry"}

thisset.discard("banana")

print(thisset)

# function clear() can delete all objects from set
thisset.clear() 

# del can delete variable from memory
del thisset
