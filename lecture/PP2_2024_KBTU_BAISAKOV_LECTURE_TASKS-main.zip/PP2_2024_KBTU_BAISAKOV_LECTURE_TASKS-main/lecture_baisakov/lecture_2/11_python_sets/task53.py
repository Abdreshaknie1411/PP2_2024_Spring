fruits = {"apple", "banana", "cherry"}
fruits.add("orange")
