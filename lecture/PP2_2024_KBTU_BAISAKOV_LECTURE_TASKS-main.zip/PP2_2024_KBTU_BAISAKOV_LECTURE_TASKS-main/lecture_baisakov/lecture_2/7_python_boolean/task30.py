print(10 > 9)   # True
