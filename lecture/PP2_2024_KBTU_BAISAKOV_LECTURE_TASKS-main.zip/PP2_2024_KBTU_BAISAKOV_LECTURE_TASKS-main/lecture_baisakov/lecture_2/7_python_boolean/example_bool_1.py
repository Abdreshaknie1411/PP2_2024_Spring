print(bool("Hello"))
print(bool(15))