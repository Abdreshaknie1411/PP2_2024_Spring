print(10 == 9)  # False
