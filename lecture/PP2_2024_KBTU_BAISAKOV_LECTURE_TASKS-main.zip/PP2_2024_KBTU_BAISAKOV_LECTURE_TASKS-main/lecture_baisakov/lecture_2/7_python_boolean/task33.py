print(bool(0))  # False
