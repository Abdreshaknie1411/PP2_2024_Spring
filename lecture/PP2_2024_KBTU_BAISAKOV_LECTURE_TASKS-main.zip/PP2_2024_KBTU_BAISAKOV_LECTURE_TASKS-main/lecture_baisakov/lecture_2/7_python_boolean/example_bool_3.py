bool(False)
bool(None)
bool(0)
bool("")
bool(())
bool([])
bool({})

# False
