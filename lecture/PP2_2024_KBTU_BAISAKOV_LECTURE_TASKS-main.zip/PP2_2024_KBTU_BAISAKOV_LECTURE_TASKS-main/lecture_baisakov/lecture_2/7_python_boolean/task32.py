print(bool("abc"))  # True

