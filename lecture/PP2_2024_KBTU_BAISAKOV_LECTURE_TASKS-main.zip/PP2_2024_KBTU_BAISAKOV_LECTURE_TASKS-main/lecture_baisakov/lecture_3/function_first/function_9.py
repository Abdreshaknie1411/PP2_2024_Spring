from math import pi

radius_of_sphere = lambda r: (4/3) * (pi * r**3)

print(radius_of_sphere(2))