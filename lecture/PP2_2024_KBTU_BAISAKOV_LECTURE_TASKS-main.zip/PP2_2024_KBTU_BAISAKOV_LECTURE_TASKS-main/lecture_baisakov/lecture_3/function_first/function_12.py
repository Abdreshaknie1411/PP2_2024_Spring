def histogram(numbers: list) -> None:
    for num in numbers:
        print('*' * num)

histogram([1, 2, 3, 4, 5, 10])
