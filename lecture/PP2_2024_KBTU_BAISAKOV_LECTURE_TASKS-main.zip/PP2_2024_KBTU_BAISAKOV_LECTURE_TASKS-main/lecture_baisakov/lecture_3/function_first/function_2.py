def to_centigrade(F: int) -> int:
    return (5 / 9) * (F - 32)

print(to_centigrade(320))