def to_ounces(grams: float = 0) -> float:
    return 28.3495231 * grams

print(to_ounces(25))