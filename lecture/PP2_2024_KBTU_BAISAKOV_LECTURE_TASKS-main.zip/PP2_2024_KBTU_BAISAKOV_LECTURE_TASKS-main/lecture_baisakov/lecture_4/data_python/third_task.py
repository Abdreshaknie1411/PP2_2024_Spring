from datetime import datetime as dt

time_now = dt.now()
print(str(time_now)[:-10])