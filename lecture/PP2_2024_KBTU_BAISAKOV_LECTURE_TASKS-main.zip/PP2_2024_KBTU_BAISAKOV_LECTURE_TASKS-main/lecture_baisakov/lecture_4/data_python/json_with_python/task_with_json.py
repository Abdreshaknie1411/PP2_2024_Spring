import json

file = open('db.json')
db = json.load(file)