from math import radians
print(f'Output radian: {radians(int(input("Input degree: "))):=5}')
