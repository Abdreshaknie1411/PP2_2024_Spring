height, first_value, second_value = int(input('Height: ')), int(input('Base, first value: ')), int(input('Base, second value: '))
print(f'Expected Output: {((first_value + second_value) / 2) * height}')
