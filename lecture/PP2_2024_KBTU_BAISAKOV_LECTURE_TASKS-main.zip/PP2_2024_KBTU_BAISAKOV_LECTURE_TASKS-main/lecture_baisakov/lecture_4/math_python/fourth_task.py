b, h = float(input('Length of base: ')), float(input('Height of parallelogram: '))
print(f'Expected Output: {b * h}')